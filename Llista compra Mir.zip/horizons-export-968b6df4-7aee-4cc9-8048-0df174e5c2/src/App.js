import React, { useState, useEffect } from 'react';
import './styles/App.css';
import Header from './components/Header';
import ProductForm from './components/ProductForm';
import ProductList from './components/ProductList';
import Cart from './components/Cart';

function App() {
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState([]);
  
  // Carregar productes del localStorage
  useEffect(() => {
    const savedProducts = localStorage.getItem('products');
    const savedCart = localStorage.getItem('cart');
    
    if (savedProducts) setProducts(JSON.parse(savedProducts));
    if (savedCart) setCart(JSON.parse(savedCart));
  }, []);
  
  // Guardar canvis al localStorage
  useEffect(() => {
    localStorage.setItem('products', JSON.stringify(products));
    localStorage.setItem('cart', JSON.stringify(cart));
  }, [products, cart]);
  
  // Afegir producte
  const addProduct = (product) => {
    setProducts([...products, { ...product, id: Date.now() }]);
  };
  
  // Afegir producte al carret
  const addToCart = (productId) => {
    const product = products.find(p => p.id === productId);
    if (product) {
      const existingItem = cart.find(item => item.id === productId);
      if (existingItem) {
        setCart(cart.map(item => 
          item.id === productId 
            ? { ...item, quantity: item.quantity + 1 } 
            : item
        ));
      } else {
        setCart([...cart, { ...product, quantity: 1 }]);
      }
    }
  };
  
  // Eliminar producte del carret
  const removeFromCart = (productId) => {
    setCart(cart.filter(item => item.id !== productId));
  };
  
  // Eliminar producte
  const deleteProduct = (productId) => {
    setProducts(products.filter(product => product.id !== productId));
    setCart(cart.filter(item => item.id !== productId));
  };
  
  return (
    <div className="App">
      <Header />
      <div className="main-container">
        <div className="left-panel">
          <ProductForm addProduct={addProduct} />
          <ProductList 
            products={products} 
            onAddToCart={addToCart} 
            onDeleteProduct={deleteProduct}
          />
        </div>
        <div className="right-panel">
          <Cart 
            cartItems={cart} 
            onRemoveFromCart={removeFromCart} 
          />
        </div>
      </div>
    </div>
  );
}

export default App;
