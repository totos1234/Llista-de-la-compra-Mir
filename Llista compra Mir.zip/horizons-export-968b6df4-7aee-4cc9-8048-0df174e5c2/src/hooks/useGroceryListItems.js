
import { useState, useEffect, useCallback } from 'react';
import { useToast } from "@/components/ui/use-toast";
import { loadItemsForStore, addItem, deleteItem, updateItem } from '@/services/itemService';
import { addItemToPurchased } from '@/services/purchasedItemService';

export const useGroceryListItems = (storeId, familyId, userName, onItemChange) => {
  const [items, setItems] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const loadListItems = useCallback(async () => {
    if (!storeId) {
        setItems([]); // Clear items if storeId is missing
        return;
    };
    setIsLoading(true);
    try {
      const loadedItems = await loadItemsForStore(storeId);
      setItems(loadedItems);
    } catch (error) {
      // Error already handled and toasted in service
      setItems([]); // Clear items on error
    } finally {
      setIsLoading(false);
    }
  }, [storeId]);

  useEffect(() => {
    loadListItems();
  }, [loadListItems]); // Rerun when storeId changes

  const handleAddItem = async (text) => {
    if (!storeId || !familyId || !userName || !text) return false;
    setIsLoading(true);
    const result = await addItem(storeId, familyId, text, userName);
    setIsLoading(false);
    if (result.success && result.data) {
      setItems(prevItems => [...prevItems, result.data]);
      toast({ title: "Producte afegit", description: `"${text}" s'ha afegit a la llista.` });
      onItemChange();
      return true;
    } else {
      toast({ title: "Error", description: result.message || "No s'ha pogut afegir el producte.", variant: result.message?.includes("ja és") ? "info" : "destructive" });
      return false;
    }
  };

  const handleDeleteItem = async (itemId) => {
    const itemToDelete = items.find(item => item.id === itemId);
    if (!itemToDelete) return false;

    setIsLoading(true);
    const result = await deleteItem(itemId);
    setIsLoading(false);
    if (result.success) {
      setItems(prevItems => prevItems.filter(item => item.id !== itemId));
      toast({ title: "Producte eliminat", description: `"${itemToDelete.text}" s'ha eliminat de la llista.` });
      onItemChange();
      return true;
    } else {
      toast({ title: "Error", description: result.message || "No s'ha pogut eliminar el producte.", variant: "destructive" });
      return false;
    }
  };

  const handleUpdateItem = async (itemId, newText) => {
     const originalItem = items.find(item => item.id === itemId);
     if (!originalItem || !userName || !newText) return false;

     const trimmedNewText = newText.trim();
     if (!trimmedNewText || trimmedNewText === originalItem.text) {
         return false; // No actual change needed
     }

     // Optimistic UI update (optional, but good for UX)
     // const originalItems = [...items];
     // setItems(prevItems => prevItems.map(item =>
     //   item.id === itemId ? { ...item, text: trimmedNewText, last_edited_by: userName, last_edited_at: new Date().toISOString() } : item
     // ));

     setIsLoading(true);
     const result = await updateItem(itemId, trimmedNewText, userName);
     setIsLoading(false);

     if (result.success && result.data) {
       // Update with final data from server
       setItems(prevItems => prevItems.map(item => item.id === itemId ? result.data : item));
       toast({ title: "Producte actualitzat", description: `"${originalItem.text}" ara és "${trimmedNewText}".` });
       onItemChange();
       return true;
     } else {
       // Revert optimistic update if implemented
       // setItems(originalItems);
       toast({ title: "Error", description: result.message || "No s'ha pogut actualitzar el producte.", variant: result.message?.includes("Ja existeix") ? "info" : "destructive" });
       return false;
     }
  };

  // Modified to accept full item and store objects
  const handlePurchaseItem = async (item, store) => {
    if (!familyId || !userName || !item || !store || !store.id || !store.name) {
        toast({ title: "Error", description: "Falten dades de la botiga o producte per completar la compra.", variant: "destructive" });
        return false;
    }
    setIsLoading(true);
    const result = await addItemToPurchased(familyId, item, store, userName);
    setIsLoading(false);
    if (result.success) {
      setItems(prevItems => prevItems.filter(i => i.id !== item.id));
      toast({ title: "Producte comprat", description: `"${item.text}" s'ha mogut a l'historial.` });
      onItemChange();
      return true;
    } else {
      toast({ title: "Error", description: result.message || "No s'ha pogut marcar com a comprat.", variant: "destructive" });
      return false;
    }
  };


  return {
    items,
    isLoading,
    handleAddItem,
    handleDeleteItem,
    handleUpdateItem,
    handlePurchaseItem,
    loadListItems // Expose reload function
  };
};
