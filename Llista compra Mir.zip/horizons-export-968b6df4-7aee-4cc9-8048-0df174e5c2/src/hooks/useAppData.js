
    import React from "react";
    import { useState, useEffect, useCallback } from 'react';
    import { useAuth } from '@/hooks/useAuth';
    import { useStores } from '@/hooks/useStores';
    import { usePurchasedItems } from '@/hooks/usePurchasedItems';
    import { addItemToPurchased } from '@/services/itemService';
    import { useToast } from "@/components/ui/use-toast";

    export const useAppData = () => {
      const auth = useAuth();
      const storesHook = useStores(auth.familyInfo?.id);
      const purchasedItemsHook = usePurchasedItems(auth.familyInfo?.id);
      // Separate loading state for data fetching (stores, purchased items)
      const [isDataLoading, setIsDataLoading] = useState(false);
      const { toast } = useToast();

      // Effect to run initial auth check
      useEffect(() => {
        auth.checkLoginStatus();
      }, [auth.checkLoginStatus]);


      // Effect to load data only when familyInfo is available AND auth check is complete
       const loadAllData = useCallback(async () => {
        // Only proceed if auth check is done AND we have a family ID
        if (auth.isCheckingAuth || !auth.familyInfo?.id) {
          setIsDataLoading(false); // Ensure data loading is false if conditions not met
          return;
        }

        setIsDataLoading(true); // Start loading app data (stores, purchased)
        try {
          await Promise.all([
            storesHook.loadStores(),
            purchasedItemsHook.loadPurchasedItems()
          ]);
           // View transition is now handled within checkLoginStatus or handleLogin in useAuth
           // based on whether familyInfo is set.
        } catch (error) {
          console.error("Error loading initial app data:", error);
          toast({ title: "Error de càrrega", description: "No s'han pogut carregar les dades inicials.", variant: "destructive" });
           // If data load fails after login, maybe stay in stores but show error?
           // Or force logout? For now, just show toast.
           // auth.setCurrentView('login'); // Avoid forcing back to login here
        } finally {
           setIsDataLoading(false); // Finish loading app data
        }
      }, [auth.familyInfo?.id, auth.isCheckingAuth, storesHook.loadStores, purchasedItemsHook.loadPurchasedItems, toast]);


      // Trigger data load when familyInfo becomes available (after login or initial check)
      // or when the auth check completes (to ensure it runs if already logged in).
      useEffect(() => {
        loadAllData();
      }, [loadAllData]); // loadAllData dependency includes familyInfo.id and isCheckingAuth


      // Handler for when an item is purchased (checkbox checked)
      const handleItemChange = useCallback(async (item, isChecked) => {
        if (!isChecked) return; // Only act when checked

        const result = await addItemToPurchased(item, auth.userName, auth.familyInfo?.id, item.store_id);

        if (result.success) {
          toast({ title: "Producte mogut!", description: `${item.text} mogut a l'historial.` });
          // Reload relevant data after purchase
          setIsDataLoading(true); // Indicate loading during refresh
           try {
               await Promise.all([
                   storesHook.loadStores(),
                   purchasedItemsHook.loadPurchasedItems()
               ]);
           } catch (error) {
               console.error("Error reloading data after purchase:", error);
               toast({ title: "Error", description: "No s'ha pogut actualitzar la llista després de la compra.", variant: "destructive" });
           } finally {
               setIsDataLoading(false);
           }
        } else {
          toast({ title: "Error", description: result.message || "No s'ha pogut moure el producte.", variant: "destructive" });
        }
      }, [auth.userName, auth.familyInfo?.id, toast, storesHook.loadStores, purchasedItemsHook.loadPurchasedItems]);

      // Overall app loading is now primarily the initial auth check
      const appIsLoading = auth.isCheckingAuth;

      return {
        auth,
        storesHook,
        purchasedItemsHook,
        handleItemChange,
        loadAllData,
        appIsLoading, // True only during initial auth check
        isDataLoading, // True when fetching stores/purchased items
      };
    };
  