import React from 'react';
import '../styles/ProductList.css';

function ProductList({ products, onAddToCart, onDeleteProduct }) {
  return (
    <div className="product-list">
      <h2>Productes Disponibles</h2>
      {products.length === 0 ? (
        <p className="empty-message">No hi ha productes disponibles</p>
      ) : (
        <ul>
          {products.map(product => (
            <li key={product.id} className="product-item">
              <div className="product-info">
                <span className="product-name">{product.name}</span>
                <span className="product-price">{product.price.toFixed(2)} €</span>
              </div>
              <div className="product-actions">
                <button
                  className="add-to-cart-btn"
                  onClick={() => onAddToCart(product.id)}
                >
                  Afegir al Carret
                </button>
                <button
                  className="delete-btn"
                  onClick={() => onDeleteProduct(product.id)}
                >
                  Eliminar
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default ProductList;
