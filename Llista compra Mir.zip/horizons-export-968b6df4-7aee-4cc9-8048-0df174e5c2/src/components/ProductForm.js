import React, { useState } from 'react';
import '../styles/ProductForm.css';

function ProductForm({ addProduct }) {
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  
  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (name.trim() && price.trim()) {
      addProduct({
        name: name.trim(),
        price: parseFloat(price),
      });
      
      // Neteja el formulari
      setName('');
      setPrice('');
    }
  };
  
  return (
    <div className="product-form">
      <h2>Afegir Producte</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="productName">Nom del Producte:</label>
          <input
            type="text"
            id="productName"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="productPrice">Preu (€):</label>
          <input
            type="number"
            id="productPrice"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            step="0.01"
            min="0"
            required
          />
        </div>
        <button type="submit">Afegir Producte</button>
      </form>
    </div>
  );
}

export default ProductForm;
