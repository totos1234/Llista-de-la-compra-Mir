import React from 'react';
import '../styles/Cart.css';

function Cart({ cartItems, onRemoveFromCart }) {
  // Calcular el total
  const calculateTotal = () => {
    return cartItems.reduce((total, item) => {
      return total + (item.price * item.quantity);
    }, 0);
  };
  
  return (
    <div className="cart">
      <h2>Cistella de la Compra</h2>
      {cartItems.length === 0 ? (
        <p className="empty-message">El carret està buit</p>
      ) : (
        <>
          <ul className="cart-items">
            {cartItems.map(item => (
              <li key={item.id} className="cart-item">
                <div className="item-info">
                  <span className="item-name">{item.name}</span>
                  <span className="item-price">{item.price.toFixed(2)} € x {item.quantity}</span>
                  <span className="item-total">{(item.price * item.quantity).toFixed(2)} €</span>
                </div>
                <button
                  className="remove-btn"
                  onClick={() => onRemoveFromCart(item.id)}
                >
                  Eliminar
                </button>
              </li>
            ))}
          </ul>
          <div className="cart-total">
            <span>Total:</span>
            <span>{calculateTotal().toFixed(2)} €</span>
          </div>
        </>
      )}
    </div>
  );
}

export default Cart;
