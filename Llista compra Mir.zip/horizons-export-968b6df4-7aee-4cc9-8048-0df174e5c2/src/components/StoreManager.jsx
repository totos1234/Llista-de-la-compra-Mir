
import React, { useState } from 'react';
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Plus, Trash2, ArrowRight, LogOut, History, Loader2, User } from "lucide-react";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";

const StoreManager = ({
    stores,
    onAddStore,
    onDeleteStore,
    onSelectStore,
    familyCode,
    userName,
    onLogout,
    onShowPurchased,
    isLoading
}) => {
  const [newStoreName, setNewStoreName] = useState("");

  const handleAdd = (e) => {
    e.preventDefault();
    if (newStoreName.trim() && !isLoading) {
      onAddStore(newStoreName.trim());
      setNewStoreName("");
    }
  };

   const handleDeleteClick = (e, storeId) => {
      e.stopPropagation();
      if (isLoading) {
          e.preventDefault();
      }
   };

  return (
    <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md mx-auto p-4 md:p-6"
    >
      <Card className="grocery-list-container flex flex-col h-[calc(100vh-4rem)] max-h-[700px]">
        <CardHeader className="border-b pb-4">
            <div className="flex justify-between items-start mb-2">
               <div>
                  <CardTitle className="text-2xl font-bold">Les Teves Llistes</CardTitle>
                  <CardDescription className="flex items-center mt-1 text-sm text-muted-foreground">
                    <User className="h-4 w-4 mr-1"/> {userName || 'Usuari'}
                    <span className="mx-2">|</span>
                    Codi: <strong className="ml-1">{familyCode || 'N/D'}</strong>
                  </CardDescription>
               </div>
                <Button variant="ghost" size="sm" onClick={onLogout} title="Tancar sessió" className="p-1 h-auto" disabled={isLoading}>
                  <LogOut className="h-5 w-5 text-muted-foreground" />
                </Button>
            </div>

          <form onSubmit={handleAdd} className="flex space-x-2 mt-4">
            <Input
              type="text"
              placeholder="Nom de la nova botiga/llista..."
              value={newStoreName}
              onChange={(e) => setNewStoreName(e.target.value)}
              className="flex-grow"
              disabled={isLoading}
            />
            <Button type="submit" disabled={!newStoreName.trim() || isLoading}>
              {isLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Plus className="h-4 w-4" />
              )}
            </Button>
          </form>
        </CardHeader>

        <CardContent className="flex-grow p-4 md:p-6 overflow-hidden flex flex-col">
           {isLoading && stores.length === 0 ? (
                <div className="flex-grow flex items-center justify-center text-muted-foreground">
                    <Loader2 className="h-5 w-5 mr-2 animate-spin" /> Carregant botigues...
                </div>
           ) : !isLoading && stores.length === 0 ? (
             <div className="flex-grow flex items-center justify-center">
                <p className="text-center text-muted-foreground">
                   No tens cap botiga creada. <br /> Afegeix-ne una per començar!
                </p>
             </div>
           ) : (
             <ScrollArea className="flex-grow -mr-4 pr-4">
                <AnimatePresence>
                    {stores.map((store) => (
                    <motion.div
                        key={store.id}
                        layout
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, height: 0, marginBottom: 0, paddingTop: 0, paddingBottom: 0 }}
                        transition={{ duration: 0.2 }}
                        onClick={() => !isLoading && onSelectStore(store)}
                        className={cn(
                          "mb-2 p-3 rounded-md bg-card border flex justify-between items-center cursor-pointer hover:bg-secondary/50 transition-colors shadow-sm",
                          isLoading && "opacity-60 cursor-not-allowed"
                        )}
                    >
                        <span className="font-medium truncate mr-2">{store.name}</span>
                        <div className="flex items-center space-x-1">
                            <AlertDialog>
                                <AlertDialogTrigger asChild disabled={isLoading}>
                                <Button
                                    variant="ghost"
                                    size="sm"
                                    className="h-7 w-7 p-0 text-destructive hover:text-destructive/90"
                                    title={`Eliminar botiga "${store.name}"`}
                                    onClick={(e) => handleDeleteClick(e, store.id)}
                                    // Removed disabled={isLoading} from Button, keep it only on Trigger
                                >
                                    <Trash2 className="h-4 w-4" />
                                </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                <AlertDialogHeader>
                                    <AlertDialogTitle>N'estàs segur?</AlertDialogTitle>
                                    <AlertDialogDescription>
                                        Això eliminarà permanentment la botiga "{store.name}" i tots els productes
                                        que conté. Aquesta acció no es pot desfer.
                                    </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                    <AlertDialogCancel>Cancel·lar</AlertDialogCancel>
                                    <AlertDialogAction
                                    onClick={() => onDeleteStore(store.id)}
                                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                    >
                                    Eliminar Botiga
                                    </AlertDialogAction>
                                </AlertDialogFooter>
                                </AlertDialogContent>
                            </AlertDialog>

                            <ArrowRight className="h-5 w-5 text-muted-foreground" />
                        </div>
                    </motion.div>
                    ))}
                </AnimatePresence>
             </ScrollArea>
           )}
           <Button
             variant="outline"
             className="mt-4 w-full"
             onClick={onShowPurchased}
             disabled={isLoading}
           >
             <History className="h-4 w-4 mr-2" /> Veure Historial de Compres
           </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default StoreManager;
