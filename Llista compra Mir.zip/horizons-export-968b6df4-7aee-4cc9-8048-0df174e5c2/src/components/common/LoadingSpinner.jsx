
import React from 'react';
import { Loader2 } from "lucide-react";

const LoadingSpinner = ({ size = 'h-12 w-12' }) => {
  return (
    <div className="min-h-screen flex items-center justify-center p-4 app-background">
      <Loader2 className={`${size} animate-spin text-primary`} />
    </div>
  );
};

export default LoadingSpinner;
