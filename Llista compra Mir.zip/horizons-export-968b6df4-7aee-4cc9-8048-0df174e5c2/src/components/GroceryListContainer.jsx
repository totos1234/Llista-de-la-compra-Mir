
import React, { useState } from "react";
import { motion } from "framer-motion";
import ListHeader from "@/components/ListHeader";
import AddItemForm from "@/components/AddItemForm";
import ItemList from "@/components/ItemList.jsx";
import { useGroceryListItems } from "@/hooks/useGroceryListItems";
import { useToast } from "@/components/ui/use-toast";

const GroceryListContainer = ({
  store,
  familyId,
  userName,
  onLogout,
  onGoBack,
  onShowPurchased,
  onItemChange,
}) => {
  const [newItemText, setNewItemText] = useState("");
  const [editingItemId, setEditingItemId] = useState(null);
  const [editText, setEditText] = useState("");
  const { toast } = useToast();

  const {
    items,
    isLoading,
    handleAddItem: addItemFromHook,
    handlePurchaseItem: purchaseItemFromHook,
    handleDeleteItem: deleteItemFromHook,
    handleUpdateItem: updateItemFromHook,
    loadListItems,
  } = useGroceryListItems(store?.id, familyId, userName, onItemChange);

  const handleAddItem = async () => {
    if (newItemText.trim()) {
      const success = await addItemFromHook(newItemText.trim());
      if (success) {
          setNewItemText("");
      }
    }
  };

  const startEditItem = (item) => {
    setEditingItemId(item.id);
    setEditText(item.text);
  };

  const cancelEditItem = () => {
    setEditingItemId(null);
    setEditText("");
  };

  const handleUpdateItem = async (itemId, newText) => {
    const success = await updateItemFromHook(itemId, newText);
    if (success) {
        cancelEditItem();
    }
  };

  const handlePurchaseItem = (item) => {
      if (store) {
          purchaseItemFromHook(item, store);
      } else {
          console.error("Store information is missing for purchase.");
          toast({ title: "Error", description: "Falta informació de la botiga per comprar.", variant: "destructive"});
      }
  };

  const handleManualSync = async () => {
    if (store?.id) {
      await loadListItems();
       toast({ title: "Sincronitzat!", description: "La llista s'ha actualitzat." });
    }
  };


  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="w-full max-w-md mx-auto p-4 sm:p-6 rounded-xl flex flex-col h-[calc(100vh-2rem)]"
    >
      <ListHeader
        title={store?.name || "Carregant..."}
        onLogout={onLogout}
        onManualSync={handleManualSync}
        lastSync={null}
        onGoBack={onGoBack}
        onShowPurchased={onShowPurchased}
        isLoading={isLoading && items.length === 0} // Show header loading only on initial load
      />

      <AddItemForm
        newItem={newItemText}
        onNewItemChange={setNewItemText}
        onAddItem={handleAddItem}
        disabled={isLoading || editingItemId !== null}
      />

      <ItemList
        items={items}
        editingItem={editingItemId}
        editText={editText}
        setEditText={setEditText}
        handlePurchaseItem={handlePurchaseItem}
        startEditItem={startEditItem}
        cancelEditItem={cancelEditItem}
        handleUpdateItem={handleUpdateItem}
        handleDeleteItem={deleteItemFromHook}
        userName={userName}
        isLoading={isLoading}
      />
    </motion.div>
  );
};

export default GroceryListContainer;
