
import { supabase } from '@/lib/supabaseClient';
import { handleSupabaseError } from '@/services/supabaseService';
import { addItem } from '@/services/itemService'; // Use itemService's addItem

export const loadPurchasedItems = async (familyId) => {
  if (!familyId) return [];
  try {
    const { data, error } = await supabase
      .from('purchased_items')
      .select('*')
      .eq('family_id', familyId)
      .order('last_purchased_at', { ascending: false });

    if (error) throw error;
    return data || [];
  } catch (error) {
    handleSupabaseError(error, 'loadPurchasedItems');
    return [];
  }
};

export const addItemToPurchased = async (familyId, item, store, userName) => { // Added userName
  if (!familyId || !item || !item.id || !item.text || !store || !store.id || !store.name || !userName) { // Added userName check
      return { success: false, message: "Falten dades per marcar el producte com a comprat." };
  }
  try {
    const purchaseTimestamp = new Date().toISOString();
    const historyEntry = { storeId: store.id, storeName: store.name, purchasedAt: purchaseTimestamp, purchasedBy: userName }; // Added purchasedBy

    const { data: existingItem, error: fetchError } = await supabase
      .from('purchased_items')
      .select('*')
      .eq('family_id', familyId)
      .ilike('text', item.text)
      .single();

    if (fetchError && fetchError.code !== 'PGRST116') {
        throw fetchError;
    }

    if (existingItem) {
      const updatedHistory = Array.isArray(existingItem.history)
         ? [...existingItem.history, historyEntry]
         : [historyEntry];

      const { error: updateError } = await supabase
        .from('purchased_items')
        .update({
          purchase_count: (existingItem.purchase_count || 0) + 1,
          last_purchased_at: purchaseTimestamp,
          last_store_id: store.id,
          last_store_name: store.name,
          last_purchased_by: userName, // Added userName
          history: updatedHistory,
          updated_at: purchaseTimestamp // Update updated_at timestamp
        })
        .eq('id', existingItem.id);

      if (updateError) throw updateError;

    } else {
      const insertTimestamp = new Date().toISOString();
      const { error: insertError } = await supabase
        .from('purchased_items')
        .insert({
          family_id: familyId,
          text: item.text,
          purchase_count: 1,
          first_added_by: item.added_by || null,
          first_added_at: item.added_at || null,
          last_purchased_at: purchaseTimestamp,
          last_store_id: store.id,
          last_store_name: store.name,
          last_purchased_by: userName, // Added userName
          history: [historyEntry],
          created_at: insertTimestamp, // Set created_at timestamp
          updated_at: insertTimestamp // Set updated_at timestamp
        });

      if (insertError) throw insertError;
    }

     const { error: deleteError } = await supabase
       .from('items')
       .delete()
       .eq('id', item.id);

     if (deleteError) {
       console.warn("Failed to delete original item after purchasing:", deleteError);
     }

    return { success: true };

  } catch (error) {
    return handleSupabaseError(error, 'addItemToPurchased');
  }
};


export const reAddItemToList = async (familyId, purchasedItem, userName) => {
  if (!familyId || !purchasedItem || !purchasedItem.last_store_id || !purchasedItem.text) {
    console.error("Cannot re-add item: missing data.", { familyId, purchasedItem });
    return { success: false, message: "Falten dades per tornar a afegir el producte." };
  }

  try {
    const { data: storeExists, error: storeCheckError } = await supabase
      .from('stores')
      .select('id, name')
      .eq('id', purchasedItem.last_store_id)
      .maybeSingle();

    if (storeCheckError) throw storeCheckError;

    if (!storeExists) {
        return { success: false, message: `La botiga original "${purchasedItem.last_store_name || ''}" ja no existeix.` };
    }

    // Use addItem from itemService
    const result = await addItem(storeExists.id, familyId, purchasedItem.text, userName);

    if (result.success) {
       return { success: true, message: `"${purchasedItem.text}" afegit de nou a la llista ${storeExists.name}.` };
    } else {
       // Provide more specific feedback if the item already exists
       if (result.message && result.message.includes('Ja existeix un producte')) {
           return { success: false, message: `"${purchasedItem.text}" ja és a la llista ${storeExists.name}.`, variant: "info" };
       }
       return { success: false, message: result.message || "Error en afegir el producte de nou." };
    }

  } catch (error) {
    return handleSupabaseError(error, 'reAddItemToList');
  }
};
