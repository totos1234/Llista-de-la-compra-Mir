
import { supabase } from '@/lib/supabaseClient';
import { handleSupabaseError } from '@/services/supabaseService';

export const loadItemsForStore = async (storeId) => {
  if (!storeId) return [];
  try {
    const { data, error } = await supabase
      .from('items')
      .select('id, text, added_by, added_at, last_edited_by, last_edited_at')
      .eq('store_id', storeId)
      .order('added_at', { ascending: true });

    if (error) throw error;
    return data || [];
  } catch (error) {
    handleSupabaseError(error, `loadItemsForStore (Store ID: ${storeId})`);
    return [];
  }
};

export const addItem = async (storeId, familyId, itemText, userName) => {
  if (!storeId || !familyId || !itemText) {
      return { success: false, message: "Falten dades per afegir el producte." };
  }
  try {
    const trimmedText = itemText.trim();
     const { data: existing, error: checkError } = await supabase
       .from('items')
       .select('id')
       .eq('store_id', storeId)
       .ilike('text', trimmedText)
       .maybeSingle();

     if (checkError) throw checkError;

     if (existing) {
       return { success: false, message: `"${trimmedText}" ja és en aquesta llista.` };
     }

    const { data, error } = await supabase
      .from('items')
      .insert({
        store_id: storeId,
        family_id: familyId,
        text: trimmedText,
        added_by: userName || null, // Ensure null if empty
      })
      .select('id, text, added_by, added_at')
      .single();

    if (error) throw error;
    return { success: true, data: data };
  } catch (error) {
     return handleSupabaseError(error, 'addItem');
  }
};

export const updateItem = async (itemId, updatedText, userName) => {
   if (!itemId || !updatedText) {
       return { success: false, message: "Falten dades per actualitzar el producte." };
   }
   try {
     const trimmedText = updatedText.trim();
     const { data: itemData, error: itemFetchError } = await supabase
       .from('items')
       .select('store_id')
       .eq('id', itemId)
       .single();

     if (itemFetchError) throw itemFetchError;
     if (!itemData) return { success: false, message: "Producte no trobat." };

     const { data: existing, error: checkError } = await supabase
       .from('items')
       .select('id')
       .eq('store_id', itemData.store_id)
       .neq('id', itemId)
       .ilike('text', trimmedText)
       .maybeSingle();

     if (checkError) throw checkError;

     if (existing) {
       return { success: false, message: `Ja existeix un altre producte amb el nom "${trimmedText}" en aquesta llista.` };
     }

     const { data, error } = await supabase
       .from('items')
       .update({
         text: trimmedText,
         last_edited_by: userName || null,
         last_edited_at: new Date().toISOString(),
       })
       .eq('id', itemId)
       .select('id, text, added_by, added_at, last_edited_by, last_edited_at')
       .single();

     if (error) throw error;
     return { success: true, data: data };
   } catch (error) {
      return handleSupabaseError(error, 'updateItem');
   }
};

export const deleteItem = async (itemId) => {
   if (!itemId) {
       return { success: false, message: "Falta l'ID del producte." };
   }
   try {
     const { error } = await supabase
       .from('items')
       .delete()
       .eq('id', itemId);

     if (error) throw error;
     return { success: true };
   } catch (error) {
     return handleSupabaseError(error, 'deleteItem');
   }
};


export const loadAllPendingItemNames = async (familyId) => {
  if (!familyId) return new Set();
  try {
    const { data, error } = await supabase
      .from('items')
      .select('text')
      .eq('family_id', familyId);

    if (error) throw error;

    const names = new Set();
    (data || []).forEach(item => {
        if(item.text) { // Ensure item.text is not null or undefined
            names.add(item.text.toLowerCase());
        }
    });
    return names;

  } catch (error) {
    handleSupabaseError(error, 'loadAllPendingItemNames');
    return new Set();
  }
};
