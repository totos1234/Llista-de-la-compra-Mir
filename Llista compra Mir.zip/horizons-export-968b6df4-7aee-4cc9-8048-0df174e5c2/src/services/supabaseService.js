
import { supabase } from '@/lib/supabaseClient';

export const handleSupabaseError = (error, context) => {
  console.error(`Supabase error (${context}):`, error);
  let userMessage = `Error (${context}): ${error.message}`;

  if (error.code === '23505') { // Unique violation
      if (context === 'addStore') {
          userMessage = `Ja existeix una botiga amb aquest nom.`;
      } else if (context === 'addItem') {
           userMessage = `Ja existeix un producte amb aquest nom en aquesta llista.`;
      } else if (context === 'updateItem') {
           userMessage = `Ja existeix un altre producte amb aquest nom en aquesta llista.`;
      } else if (context === 'getOrCreateFamily') {
           userMessage = `Error en crear la família. Potser el codi ja existeix? ${error.message}`;
      }
  } else if (error.code === 'PGRST116') { // Row not found (useful for single() checks)
       if (context === 'getOrCreateFamily') {
           // This is expected when family doesn't exist, handled in the function
           return { success: true, data: null, error: null }; // Indicate not found, but not an actual error
       } else {
           userMessage = `No s'ha trobat el registre (${context}). ${error.message}`;
       }
  }

  return { success: false, message: userMessage, error };
};

