
    import React from "react";
    import { Toaster } from "@/components/ui/toaster";
    import AppRouter from "@/components/AppRouter";
    import MainLayout from "@/components/layout/MainLayout";
    import LoadingSpinner from "@/components/common/LoadingSpinner";
    import { useAppData } from "@/hooks/useAppData";

    const App = () => {
      const {
        auth,
        storesHook,
        purchasedItemsHook,
        handleItemChange,
        loadAllData,
        appIsLoading, // This is now ONLY for the initial auth check
        isDataLoading, // This is for subsequent data loads (stores, purchased)
      } = useAppData();

       // Show loading spinner ONLY during the initial authentication check
       if (appIsLoading) {
          return <LoadingSpinner />;
       }

       // Pass relevant loading states down to the router/views
       const isLoginActionLoading = auth.isLoggingIn;
       const storesLoading = storesHook.isLoading || isDataLoading; // Combine hook loading with general data loading
       const purchasedLoading = purchasedItemsHook.isLoading || isDataLoading; // Combine hook loading with general data loading

      return (
        <MainLayout viewKey={auth.currentView}>
          <AppRouter
            auth={auth}
            storesHook={{...storesHook, isLoading: storesLoading}} // Pass updated loading state
            purchasedItemsHook={{...purchasedItemsHook, isLoading: purchasedLoading}} // Pass updated loading state
            handleItemChange={handleItemChange}
            loadAllData={loadAllData}
            isLoginActionLoading={isLoginActionLoading}
            isDataLoading={isDataLoading} // Pass general data loading state if needed
          />
          <Toaster />
        </MainLayout>
      );
    };

    export default App;
  