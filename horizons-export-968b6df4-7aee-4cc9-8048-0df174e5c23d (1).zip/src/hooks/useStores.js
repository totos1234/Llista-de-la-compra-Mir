
import { useState, useCallback } from 'react';
import { useToast } from "@/components/ui/use-toast";
import { loadStores, addStore, deleteStore } from "@/services/storeService";

export const useStores = (familyId) => {
  const [stores, setStores] = useState([]);
  const [currentStore, setCurrentStore] = useState(null);
  const { toast } = useToast();


  const loadStoresData = useCallback(async () => {
    // This function now focuses only on loading stores
    // The overall loading state is managed externally (e.g., in useAuth or App)
    try {
      if (!familyId) {
        setStores([]);
        return [];
      }
      const loadedStores = await loadStores(familyId);
      setStores(loadedStores); // Update local state
      return loadedStores; // Return data for Promise.all or direct use
    } catch (error) {
      console.error("Error loading stores:", error);
      toast({ title: "Error", description: "No s'han pogut carregar les botigues.", variant: "destructive" });
      setStores([]); // Clear local state on error
      throw error; // Re-throw error for caller (e.g., Promise.all) to catch
    }
  }, [familyId, toast]); // Depend only on familyId and toast

  const handleAddStore = async (storeName, setIsLoadingCallback) => {
     if (!familyId) return;
     setIsLoadingCallback(true); // Use callback to set loading
     const result = await addStore(familyId, storeName);
     if (result.success && result.data) {
       setStores(prevStores => [...prevStores, result.data]);
       toast({ title: "Botiga afegida", description: `"${storeName}" s'ha creat correctament.` });
     } else {
       toast({ title: "Error", description: result.message || "No s'ha pogut afegir la botiga", variant: "destructive" });
     }
     setIsLoadingCallback(false); // Use callback to stop loading
  };

  const handleDeleteStore = async (storeId, setIsLoadingCallback, loadAllDataCallback) => {
     const storeToDelete = stores.find(s => s.id === storeId);
     if (!familyId || !storeToDelete) return;

     setIsLoadingCallback(true); // Use callback
     const result = await deleteStore(storeId);
     if (result.success) {
        // Update local state first
        setStores(prevStores => prevStores.filter(store => store.id !== storeId));
        toast({
            title: "Botiga eliminada",
            description: `La botiga "${storeToDelete.name}" ha estat eliminada.`,
            variant: "default"
        });
        // Optionally trigger a full data reload if deletion has side effects elsewhere
        if (loadAllDataCallback) {
            // Use the callback to reload all data, it handles setIsLoading itself
           await loadAllDataCallback(familyId);
        } else {
            setIsLoadingCallback(false); // Fallback if callback isn't provided
        }
     } else {
         toast({ title: "Error", description: result.message || "No s'ha pogut eliminar la botiga.", variant: "destructive" });
         setIsLoadingCallback(false); // Use callback to stop loading on error
     }
     // setIsLoadingCallback(false) should be handled by the callback on success or error case above
  };

  const handleSelectStore = (store, setCurrentViewCallback) => {
    setCurrentStore(store);
    setCurrentViewCallback('list');
  };

  const handleGoBackToStores = (setCurrentViewCallback) => {
    setCurrentStore(null);
    setCurrentViewCallback('stores');
  };

  return {
    stores,
    setStores, // Keep setter for App.jsx to clear on logout
    currentStore,
    setCurrentStore,
    loadStoresData, // Expose the specific loader
    handleAddStore,
    handleDeleteStore,
    handleSelectStore,
    handleGoBackToStores,
  };
};
