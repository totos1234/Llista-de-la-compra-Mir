
import { useState, useCallback } from 'react';
import { useToast } from "@/components/ui/use-toast";
import { loadPurchasedItems, reAddItemToList } from "@/services/purchasedItemService"; // Corrected import
import { loadAllPendingItemNames } from "@/services/itemService"; // Added import from correct service

export const usePurchasedItems = (familyId, userName) => {
  const [purchasedItems, setPurchasedItems] = useState([]);
  const [pendingItemNames, setPendingItemNames] = useState(new Set());
  const { toast } = useToast();

  const loadPurchasedData = useCallback(async () => {
     // Removed the check for familyId here, let App call this when familyId is ready
    try {
        if (!familyId) { // Check inside if needed
             setPurchasedItems([]);
             setPendingItemNames(new Set());
             return { purchased: [], pending: new Set() };
        }
      const [loadedPurchased, loadedPending] = await Promise.all([
        loadPurchasedItems(familyId),
        loadAllPendingItemNames(familyId) // This function is now correctly imported
      ]);
      setPurchasedItems(loadedPurchased);
      setPendingItemNames(loadedPending);
      return { purchased: loadedPurchased, pending: loadedPending };
    } catch (error) {
      console.error("Error loading purchased/pending items:", error);
      toast({ title: "Error", description: "No s'han pogut carregar les dades de l'historial.", variant: "destructive" });
      setPurchasedItems([]);
      setPendingItemNames(new Set());
      return { purchased: [], pending: new Set() };
    }
  }, [familyId, toast]); // Depend on familyId

  const refreshPendingItems = useCallback(async () => {
    if (!familyId) return;
    try {
      const names = await loadAllPendingItemNames(familyId); // This function is now correctly imported
      setPendingItemNames(names);
    } catch (error) {
       console.error("Error refreshing pending items:", error);
       // Maybe add a silent toast? For now, just log.
    }
  }, [familyId]);

  const handleShowPurchased = async (setCurrentView, setIsLoading) => {
     if (!familyId) return;
     setIsLoading(true);
     await loadPurchasedData(); // Reload data right before showing
     setCurrentView('purchased');
     setIsLoading(false);
  };

  const handleReAddItem = async (purchasedItem, setIsLoading) => {
    if (!familyId || !userName) return;
    setIsLoading(true);
    const result = await reAddItemToList(familyId, purchasedItem, userName);
    toast({
      title: result.success ? "Producte afegit" : "Informació",
      description: result.message || (result.success ? "Producte afegit correctament." : "Error desconegut."),
      variant: result.success ? "default" : "info"
    });
    if (result.success) {
       await refreshPendingItems(); // Await refresh after successful add
    }
    setIsLoading(false);
  };

  return {
    purchasedItems,
    setPurchasedItems,
    pendingItemNames,
    setPendingItemNames,
    loadPurchasedData,
    refreshPendingItems,
    handleShowPurchased,
    handleReAddItem,
  };
};
