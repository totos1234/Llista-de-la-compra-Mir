
    import React from "react";
    import { useState, useEffect, useCallback } from 'react';
    import { useToast } from "@/components/ui/use-toast";
    import { getOrCreateFamily } from '@/services/familyService';
    import { getUserData, saveUserData, clearUserData } from '@/utils/localStorage';

    export const useAuth = () => {
      const [userName, setUserName] = useState('');
      const [familyCode, setFamilyCode] = useState('');
      const [familyInfo, setFamilyInfo] = useState(null); // Stores { id, code }
      const [isCheckingAuth, setIsCheckingAuth] = useState(true); // Loading state for initial auth check
      const [isLoggingIn, setIsLoggingIn] = useState(false); // Loading state specifically for login action
      const [currentView, setCurrentView] = useState('loading'); // Start as loading until auth check done
      const { toast } = useToast();

      const checkLoginStatus = useCallback(async () => {
        setIsCheckingAuth(true); // Indicate initial check is starting
        setCurrentView('loading');
        try {
          const userData = getUserData();
          if (userData?.userName && userData?.familyCode && userData?.familyId) {
            setUserName(userData.userName);
            setFamilyCode(userData.familyCode);
            setFamilyInfo({ id: userData.familyId, code: userData.familyCode });
            setCurrentView('stores'); // Go to stores if logged in
          } else {
            clearUserData();
            setUserName('');
            setFamilyCode('');
            setFamilyInfo(null);
            setCurrentView('login'); // Go to login if not logged in
          }
        } catch (error) {
            console.error("Error checking login status:", error);
            clearUserData();
            setUserName('');
            setFamilyCode('');
            setFamilyInfo(null);
            setCurrentView('login'); // Default to login on error
        } finally {
            setIsCheckingAuth(false); // Initial check finished
        }
      }, []); // Removed toast dependency

      const handleLogin = async (name, code) => {
        setIsLoggingIn(true); // Indicate login process is starting
        // Don't change currentView here, let useAppData handle it based on familyInfo change
        const result = await getOrCreateFamily(code);

        if (result.success && result.data) {
          const familyData = result.data;
          setFamilyInfo(familyData); // This change will trigger data loading in useAppData
          setUserName(name);
          setFamilyCode(code);
          saveUserData(name, code, familyData.id);
          // setCurrentView('stores'); // Removed: useAppData will handle view transition after data load
          toast({ title: "Benvingut/da!", description: `Has entrat com ${name} a la família ${code}.` });
        } else {
          const errorMessage = result.message || "No s'ha pogut accedir o crear la família.";
          toast({ title: "Error d'accés", description: errorMessage, variant: "destructive" });
          setCurrentView('login'); // Explicitly return to login on failure
        }
        setIsLoggingIn(false); // Indicate login process finished
      };

      const handleLogout = () => {
        clearUserData();
        setUserName('');
        setFamilyCode('');
        setFamilyInfo(null); // This change will trigger cleanup in useAppData
        setCurrentView('login');
        toast({ title: "Sessió tancada", description: "Has sortit de l'aplicació." });
      };

      // Expose both loading states if needed by UI components
      const isLoading = isCheckingAuth || isLoggingIn;

      return {
        userName,
        familyCode,
        familyInfo,
        isLoading, // Combined loading state for general UI disabling
        isCheckingAuth, // Specific state for initial load indication
        isLoggingIn, // Specific state for login button indication
        currentView,
        setCurrentView,
        checkLoginStatus,
        handleLogin,
        handleLogout,
      };
    };
  