
    import React from "react";

    const USER_NAME_KEY = "groceryAppUserName";
    const FAMILY_CODE_KEY = "groceryAppFamilyCode";
    const FAMILY_ID_KEY = "groceryAppFamilyId";

    export const saveUserData = (userName, familyCode, familyId) => {
      try {
        localStorage.setItem(USER_NAME_KEY, userName);
        localStorage.setItem(FAMILY_CODE_KEY, familyCode);
        localStorage.setItem(FAMILY_ID_KEY, familyId);
      } catch (error) {
        console.error("Error saving user data to localStorage:", error);
      }
    };

    export const getUserData = () => {
      try {
        const userName = localStorage.getItem(USER_NAME_KEY);
        const familyCode = localStorage.getItem(FAMILY_CODE_KEY);
        const familyId = localStorage.getItem(FAMILY_ID_KEY);

        if (userName && familyCode && familyId) {
          return { userName, familyCode, familyId };
        }
        return null;
      } catch (error) {
        console.error("Error getting user data from localStorage:", error);
        return null;
      }
    };

    export const clearUserData = () => {
      try {
        localStorage.removeItem(USER_NAME_KEY);
        localStorage.removeItem(FAMILY_CODE_KEY);
        localStorage.removeItem(FAMILY_ID_KEY);
      } catch (error) {
        console.error("Error clearing user data from localStorage:", error);
      }
    };
  