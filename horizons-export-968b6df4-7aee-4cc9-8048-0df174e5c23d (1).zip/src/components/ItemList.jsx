
import React from 'react';
import { motion, AnimatePresence } from "framer-motion";
import GroceryItem from "@/components/GroceryItem";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Loader2 } from 'lucide-react';

const ItemList = ({
    items,
    editingItem,
    editText,
    setEditText,
    handlePurchaseItem,
    startEditItem,
    cancelEditItem,
    handleUpdateItem,
    handleDeleteItem,
    userName,
    isLoading
}) => {
  return (
    <ScrollArea className="flex-grow mb-4 pr-3 -mr-3 relative min-h-[100px]">
      {isLoading && items.length === 0 && (
        <div className="absolute inset-0 bg-background/70 flex flex-col items-center justify-center z-10 rounded-md">
          <Loader2 className="h-6 w-6 animate-spin mb-2"/>
          <p className="text-sm text-muted-foreground">Carregant productes...</p>
        </div>
      )}
      <AnimatePresence>
        {!isLoading && items.length === 0 ? (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="text-center text-muted-foreground py-8"
          >
            Aquesta llista és buida. Afegeix productes amb el formulari de dalt.
          </motion.p>
        ) : (
          items.map((item) => (
            <GroceryItem
              key={item.id}
              item={item}
              isEditing={editingItem === item.id}
              editText={editText}
              onEditChange={setEditText}
              onToggleComplete={() => handlePurchaseItem(item)}
              onStartEdit={startEditItem}
              onCancelEdit={cancelEditItem}
              onUpdateItem={handleUpdateItem}
              onDeleteItem={handleDeleteItem}
              disabled={isLoading}
            />
          ))
        )}
      </AnimatePresence>
    </ScrollArea>
  );
};

export default ItemList;
