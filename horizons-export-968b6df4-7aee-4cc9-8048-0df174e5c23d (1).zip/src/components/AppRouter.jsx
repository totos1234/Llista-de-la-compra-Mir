
    import React from 'react';
    import LoginView from '@/components/views/LoginView';
    import StoresView from '@/components/views/StoresView';
    import ListView from '@/components/views/ListView';
    import PurchasedView from '@/components/views/PurchasedView';
    import LoadingSpinner from '@/components/common/LoadingSpinner';

    // Accept isDataLoading as well
    const AppRouter = ({ auth, storesHook, purchasedItemsHook, handleItemChange, loadAllData, isLoginActionLoading, isDataLoading }) => {
      const { currentView, handleLogin, handleLogout, userName, familyInfo, setCurrentView } = auth;
      // Use the isLoading passed down from App.jsx which combines hook state and isDataLoading
      const { stores, addStore, deleteStore, selectedStore, setSelectedStore, isLoading: storesLoading } = storesHook;
      const { purchasedItems, clearPurchasedItems, isLoading: purchasedLoading } = purchasedItemsHook;

      // Initial auth check loading is handled in App.jsx now

      switch (currentView) {
        case 'login':
          // Pass the specific loading state for the login *action*
          return <LoginView onCodeSubmit={handleLogin} isLoading={isLoginActionLoading} />;
        case 'stores':
          return (
            <StoresView
              stores={stores}
              onAddStore={addStore}
              onDeleteStore={deleteStore}
              onSelectStore={(store) => {
                setSelectedStore(store);
                setCurrentView('list');
              }}
              onViewPurchased={() => setCurrentView('purchased')}
              // Use the combined loading state for stores view
              isLoading={storesLoading}
              onLogout={handleLogout}
              userName={userName}
            />
          );
        case 'list':
          if (!selectedStore) {
              setCurrentView('stores'); // Go back if no store selected somehow
              return <LoadingSpinner />; // Show spinner during brief redirect
          }
          return (
            <ListView
              store={selectedStore}
              familyId={familyInfo?.id}
              userName={userName}
              onBack={() => {
                  setSelectedStore(null);
                  setCurrentView('stores');
              }}
              onItemPurchased={handleItemChange}
              onViewPurchased={() => setCurrentView('purchased')}
              onLogout={handleLogout}
              // List view might need its own item loading state from a dedicated hook later
              // For now, rely on the general data loading state if needed
              isLoading={isDataLoading}
            />
          );
        case 'purchased':
          return (
            <PurchasedView
              items={purchasedItems}
              // Use the combined loading state for purchased items view
              isLoading={purchasedLoading}
              onClearHistory={clearPurchasedItems}
              onBack={() => setCurrentView('stores')}
              onLogout={handleLogout}
              userName={userName}
            />
          );
         case 'loading': // Generic loading state shown by useAuth during transitions or initial check
           return <LoadingSpinner />;
        default:
          // Default to login view if state is unexpected
          return <LoginView onCodeSubmit={handleLogin} isLoading={isLoginActionLoading} />;
      }
    };

    export default AppRouter;
  