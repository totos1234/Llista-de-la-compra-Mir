
import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ArrowLeft, History, ShoppingBag, CalendarDays, Hash, SortAsc, SortDesc, Loader2, User } from "lucide-react"; // Added User icon
import { cn } from "@/lib/utils";

const PurchasedItemsList = ({
    purchasedItems,
    pendingItemNames,
    onGoBack,
    onReAddItem,
    isLoading // Receive isLoading prop
}) => {
  const [sortConfig, setSortConfig] = useState({ key: 'last_purchased_at', direction: 'desc' }); // Use DB column name

  const formatDate = (dateString) => {
    if (!dateString) return 'N/D';
    try {
      return new Date(dateString).toLocaleDateString('ca-ES', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch (error) {
      return 'Data invàlida';
    }
  };

  const sortedItems = useMemo(() => {
    let sortableItems = [...purchasedItems];
    if (sortConfig.key !== null) {
      sortableItems.sort((a, b) => {
        let aValue = a[sortConfig.key];
        let bValue = b[sortConfig.key];

        if (sortConfig.key === 'last_purchased_at') { // Use DB column name
           aValue = new Date(aValue || 0);
           bValue = new Date(bValue || 0);
        } else if (sortConfig.key === 'text' || sortConfig.key === 'last_purchased_by') { // Added last_purchased_by
          aValue = aValue?.toLowerCase() || '';
          bValue = bValue?.toLowerCase() || '';
        } else if (sortConfig.key === 'purchase_count') { // Use DB column name
           aValue = aValue || 0;
           bValue = bValue || 0;
        }

        if (aValue < bValue) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (aValue > bValue) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }

        // Secondary sort by name if primary values are equal
        const aText = a.text?.toLowerCase() || '';
        const bText = b.text?.toLowerCase() || '';
        if (aText < bText) return -1;
        if (aText > bText) return 1;

        return 0;
      });
    }
    return sortableItems;
  }, [purchasedItems, sortConfig]);

  const requestSort = (key) => {
    let direction = 'asc';
    // Default to desc for date and count
    if (key === 'last_purchased_at' || key === 'purchase_count') {
      direction = 'desc';
    }
    // If clicking the same key, toggle direction
    if (sortConfig.key === key) {
        direction = sortConfig.direction === 'asc' ? 'desc' : 'asc';
    }

    setSortConfig({ key, direction });
  };

  const getSortIcon = (key) => {
    if (sortConfig.key !== key) return null;
    return sortConfig.direction === 'asc' ? <SortAsc className="h-4 w-4 ml-1" /> : <SortDesc className="h-4 w-4 ml-1" />;
  };


  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="w-full max-w-md mx-auto p-4 md:p-6 rounded-xl grocery-list-container" // Adjusted padding
    >
      <div className="flex items-center justify-between mb-4">
        <Button variant="ghost" size="sm" onClick={onGoBack} className="p-1 h-auto mr-2" disabled={isLoading}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div className="flex items-center overflow-hidden mr-auto">
          <History className="h-6 w-6 text-primary mr-2 flex-shrink-0" />
          <h2 className="text-xl font-bold truncate">Historial de Compres</h2>
        </div>
         {/* Show loader next to title if loading */}
         {isLoading && <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />}
      </div>

      <div className="flex justify-center space-x-2 mb-4">
          <Button
            variant={sortConfig.key === 'last_purchased_at' ? 'secondary' : 'outline'}
            size="sm"
            onClick={() => requestSort('last_purchased_at')}
            className="flex items-center"
            disabled={isLoading} // Disable sort buttons while loading
          >
             Data {getSortIcon('last_purchased_at')}
          </Button>
          <Button
            variant={sortConfig.key === 'text' ? 'secondary' : 'outline'}
            size="sm"
            onClick={() => requestSort('text')}
            className="flex items-center"
            disabled={isLoading}
          >
            Nom {getSortIcon('text')}
          </Button>
          <Button
             variant={sortConfig.key === 'purchase_count' ? 'secondary' : 'outline'}
             size="sm"
             onClick={() => requestSort('purchase_count')}
             className="flex items-center"
             disabled={isLoading}
           >
             Quantitat {getSortIcon('purchase_count')}
           </Button>
           {/* Optional: Add sort by user button */}
           {/*
           <Button
             variant={sortConfig.key === 'last_purchased_by' ? 'secondary' : 'outline'}
             size="sm"
             onClick={() => requestSort('last_purchased_by')}
             className="flex items-center"
             disabled={isLoading}
           >
             Usuari {getSortIcon('last_purchased_by')}
           </Button>
           */}
      </div>

      <p className="text-xs text-muted-foreground mb-4 text-center">Clica en un producte per afegir-lo de nou a la seva llista.</p>


      <ScrollArea className="h-[calc(100vh-18rem)] max-h-[450px] pr-4 -mr-4 relative">
          {/* Optional Loading Overlay */}
         {isLoading && purchasedItems.length > 0 && ( // Show overlay only if there are items but loading
           <div className="absolute inset-0 bg-background/50 flex items-center justify-center z-10 rounded-md">
             <p>Processant...</p>
           </div>
         )}
        <AnimatePresence>
          {isLoading && purchasedItems.length === 0 ? ( // Show loading if loading and no items yet
              <div className="text-center text-muted-foreground py-10">
                  <Loader2 className="h-5 w-5 mx-auto mb-2 animate-spin" /> Carregant historial...
              </div>
          ) : !isLoading && sortedItems.length === 0 ? ( // Show message if not loading and no items
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="text-center text-muted-foreground py-4"
            >
              Encara no has comprat res.
            </motion.p>
          ) : (
            sortedItems.map((item) => {
              const isPending = pendingItemNames.has(item.text.toLowerCase());
              const canReAdd = item.last_store_id && !isLoading; // Check if re-add is possible and not loading
              return (
                <motion.div
                  key={item.id}
                  layout
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, height: 0, marginBottom: 0, paddingTop: 0, paddingBottom: 0 }}
                  transition={{ duration: 0.2 }}
                  className={cn(
                    "mb-3 p-4 rounded-md bg-card border flex justify-between items-start transition-colors",
                    canReAdd ? "cursor-pointer hover:bg-secondary/50" : "cursor-not-allowed opacity-60",
                    isLoading && "opacity-50" // General dimming while loading
                  )}
                  onClick={() => canReAdd && onReAddItem(item)}
                  title={
                    isLoading ? "Processant..." :
                    canReAdd ? `Afegir "${item.text}" de nou a ${item.last_store_name || 'la llista original'}` :
                    !item.last_store_id ? "No es pot afegir (falta botiga original)" : ""
                   }
                >
                  <div className="flex-grow mr-2 flex items-center space-x-3">
                    {/* Status Indicator */}
                    <div className="w-4 h-4 flex-shrink-0 flex items-center justify-center">
                      {isPending ? (
                        <ArrowLeft className="h-4 w-4 text-green-600" title="Pendent en una llista" />
                      ) : (
                        <div
                          className="w-2.5 h-2.5 rounded-full bg-red-500"
                          title="No és a cap llista"
                        ></div>
                      )}
                    </div>

                    <div>
                      <p className="font-semibold mb-1">{item.text}</p>
                      <div className="text-sm text-muted-foreground space-y-1">
                        <div className="flex items-center">
                          <Hash className="h-3 w-3 mr-1.5 flex-shrink-0" />
                          <span>Comprat: {item.purchase_count || 0} {item.purchase_count === 1 ? 'vegada' : 'vegades'}</span>
                        </div>
                        <div className="flex items-center">
                          <ShoppingBag className="h-3 w-3 mr-1.5 flex-shrink-0" />
                          <span className="truncate" title={item.last_store_name || 'N/D'}>Últ. botiga: {item.last_store_name || 'N/D'}</span>
                        </div>
                        <div className="flex items-center">
                          <CalendarDays className="h-3 w-3 mr-1.5 flex-shrink-0" />
                          <span>Últ. compra: {formatDate(item.last_purchased_at)}</span>
                        </div>
                         <div className="flex items-center">
                           <User className="h-3 w-3 mr-1.5 flex-shrink-0" />
                           <span>Últ. comprat per: {item.last_purchased_by || 'N/D'}</span>
                         </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )
            })
          )}
        </AnimatePresence>
      </ScrollArea>
    </motion.div>
  );
};

export default PurchasedItemsList;
