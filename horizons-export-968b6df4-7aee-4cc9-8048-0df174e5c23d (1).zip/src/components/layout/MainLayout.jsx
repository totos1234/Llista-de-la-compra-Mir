
import React from 'react';
import { motion, AnimatePresence } from "framer-motion";

const MainLayout = ({ children, viewKey }) => {
  return (
    <div className="min-h-screen flex items-center justify-center p-4 app-background">
      <AnimatePresence mode="wait">
        <motion.div
          key={viewKey} // Animation key depends on the view
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -15 }}
          transition={{ duration: 0.25 }}
          className="w-full max-w-md h-[calc(100vh-2rem)]" // Container takes height
        >
          {children}
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

export default MainLayout;
