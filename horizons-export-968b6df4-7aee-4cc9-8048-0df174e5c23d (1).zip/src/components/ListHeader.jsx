
import React from 'react';
import { Button } from "@/components/ui/button";
import { ArrowLeft, LogOut, History, RefreshCw, Loader2 } from "lucide-react";

const ListHeader = ({ 
  title, 
  onLogout, 
  onManualSync, 
  lastSync, 
  onGoBack, 
  onShowPurchased,
  isLoading // Receive isLoading prop
}) => {

  const formatLastSync = (date) => {
    if (!date) return 'Mai';
    const now = new Date();
    const diffSeconds = Math.round((now - date) / 1000);
    if (diffSeconds < 5) return 'Ara mateix';
    if (diffSeconds < 60) return `Fa ${diffSeconds} segons`;
    const diffMinutes = Math.round(diffSeconds / 60);
    if (diffMinutes < 60) return `Fa ${diffMinutes} minuts`;
    return date.toLocaleTimeString('ca-ES');
  };

  return (
    <div className="mb-4">
      <div className="flex items-center justify-between mb-2">
        <Button variant="ghost" size="sm" onClick={onGoBack} className="p-1 h-auto mr-2" disabled={isLoading}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h2 className="text-xl font-bold truncate mr-auto">{title}</h2>
        <div className="flex items-center space-x-1">
          <Button variant="ghost" size="sm" onClick={onShowPurchased} className="p-1 h-auto" title="Veure Historial" disabled={isLoading}>
             <History className="h-5 w-5 text-muted-foreground" />
          </Button>
          <Button variant="ghost" size="sm" onClick={onLogout} className="p-1 h-auto" title="Tancar sessió" disabled={isLoading}>
            <LogOut className="h-5 w-5 text-muted-foreground" />
          </Button>
        </div>
      </div>
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span>Última sinc: {formatLastSync(lastSync)}</span>
        <Button variant="ghost" size="sm" onClick={onManualSync} className="p-1 h-auto text-xs" disabled={isLoading}>
          {isLoading ? <Loader2 className="h-3 w-3 mr-1 animate-spin"/> : <RefreshCw className="h-3 w-3 mr-1"/>} 
          Sincronitzar
        </Button>
      </div>
    </div>
  );
};

export default ListHeader;
