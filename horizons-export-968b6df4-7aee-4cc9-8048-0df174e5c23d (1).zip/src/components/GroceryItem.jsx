
import React from 'react';
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Trash2, Edit, Save, X } from "lucide-react"; // Added X icon
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";

const GroceryItem = ({
  item,
  isEditing,
  editText,
  onEditChange,
  onToggleComplete,
  onStartEdit,
  onCancelEdit,
  onUpdateItem, // Renamed from onSaveEdit
  onDeleteItem,
  // userName, // userName might not be needed directly here if handled by hooks
  disabled
}) => {

  const handleSave = (e) => {
    e.preventDefault(); // Prevent form submission if inside a form
    e.stopPropagation(); // Stop event bubbling
     if (!disabled) {
        onUpdateItem(item.id, editText); // Pass itemId and new text
     }
  };

  const handleCancel = (e) => {
      e?.stopPropagation(); // Optional chaining for event
      onCancelEdit();
  }

  const stopPropagation = (e) => {
    e.stopPropagation();
  };

  const handleMainClick = () => {
      if (!isEditing && !disabled) {
        onToggleComplete(); // Call without args, hook knows the item
      }
  };

  const handleEditClick = (e) => {
      stopPropagation(e);
      if (!disabled) {
         onStartEdit(item);
      }
  }

   const handleDeleteClick = (e) => {
      stopPropagation(e);
      // No specific logic needed here, Dialog trigger handles disabled state
  }

  return (
    <motion.div
      key={item.id}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, height: 0, marginBottom: 0, paddingTop: 0, paddingBottom: 0 }}
      transition={{ duration: 0.2 }}
      layout
      className={cn(
        "flex items-center justify-between p-3 rounded-md grocery-item bg-card border mb-2 shadow-md transition-shadow",
        !isEditing && !disabled && "cursor-pointer hover:shadow-lg",
        isEditing && !disabled && "ring-2 ring-primary ring-offset-2 ring-offset-background cursor-default",
        disabled && "opacity-60 cursor-not-allowed"
      )}
      onClick={handleMainClick}
      title={
         disabled ? "Processant..." :
         isEditing ? "" :
         `Marcar "${item.text}" com a comprat`
      }
    >
      <div className="flex items-center space-x-3 flex-grow mr-2 overflow-hidden">

        {isEditing ? (
           <div className="flex-grow flex space-x-2" onClick={stopPropagation}>
            <Input
              value={editText}
              onChange={(e) => onEditChange(e.target.value)}
              className="h-8 py-1 flex-grow"
              autoFocus
              onKeyDown={(e) => { if (e.key === 'Enter') handleSave(e); if (e.key === 'Escape') handleCancel(e); }}
              // Removed onBlur={handleCancel} to allow clicking save button
              disabled={disabled}
            />
            <Button
              variant="ghost"
              size="sm"
              onClick={handleSave}
              className="h-8 w-8 p-0 flex-shrink-0"
              disabled={!editText?.trim() || disabled}
              title="Desar canvis"
              type="button" // Explicitly type button
            >
              <Save className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleCancel}
              className="h-8 w-8 p-0 flex-shrink-0"
              title="Cancel·lar edició"
              type="button" // Explicitly type button
              disabled={disabled}
            >
              <X className="h-4 w-4" />
            </Button>
           </div>
        ) : (
          <div className="flex flex-col overflow-hidden ml-2">
             <span
               className={cn(
                   "text-sm font-medium truncate",
                   !disabled && "cursor-pointer"
               )}
               title={item.text}
             >
               {item.text}
             </span>
            <span className="text-xs text-muted-foreground truncate" title={`Afegit per ${item.added_by || 'desconegut'}`}>
              Per: {item.added_by || 'desconegut'}
            </span>
             {item.last_edited_by && (
               <span className="text-xs text-muted-foreground/80 truncate italic" title={`Editat per ${item.last_edited_by} el ${new Date(item.last_edited_at).toLocaleString('ca-ES')}`}>
                 (editat)
               </span>
             )}
          </div>
        )}
      </div>

      {!isEditing && (
          <div className="flex space-x-1 flex-shrink-0" onClick={stopPropagation}>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleEditClick}
                className="h-8 w-8 p-0"
                title="Editar producte"
                disabled={disabled}
              >
                <Edit className="h-4 w-4" />
              </Button>
            <AlertDialog>
              <AlertDialogTrigger asChild disabled={disabled}>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0 text-destructive hover:text-destructive/90"
                  title="Eliminar producte"
                  onClick={handleDeleteClick} // Still useful for analytics or complex logic if needed later
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>N'estàs segur?</AlertDialogTitle>
                  <AlertDialogDescription>
                    Aquesta acció no es pot desfer. Això eliminarà permanentment
                    el producte "{item.text}" d'aquesta llista.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel·lar</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={() => onDeleteItem(item.id)} // Pass item.id here
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                  >
                    Eliminar
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
      )}
    </motion.div>
  );
};

export default GroceryItem;
