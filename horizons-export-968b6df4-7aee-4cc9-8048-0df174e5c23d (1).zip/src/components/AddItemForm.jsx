
import React from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Loader2 } from "lucide-react"; // Import Loader2

const AddItemForm = ({ newItem, onNewItemChange, onAddItem, disabled }) => { // Receive disabled prop
  
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!disabled) { // Prevent submit if disabled
       onAddItem();
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex space-x-2 mb-4">
      <Input
        type="text"
        placeholder="Afegir producte..."
        value={newItem}
        onChange={(e) => onNewItemChange(e.target.value)}
        className="flex-grow"
        disabled={disabled} // Disable input
      />
      <Button type="submit" disabled={!newItem.trim() || disabled}>
        {disabled ? (
           <Loader2 className="h-4 w-4 mr-1 animate-spin" />
        ) : (
           <Plus className="h-4 w-4 mr-1" />
        )}
        {disabled ? 'Afegint...' : 'Afegir'}
      </Button>
    </form>
  );
};

export default AddItemForm;
