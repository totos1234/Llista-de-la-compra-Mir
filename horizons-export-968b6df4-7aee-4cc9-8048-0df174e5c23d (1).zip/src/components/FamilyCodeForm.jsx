
import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { motion } from "framer-motion";
import { LogIn, User, Users, Loader2 } from 'lucide-react'; // Import Loader2

const FamilyCodeForm = ({ onCodeSubmit, savedFamilyCode, savedUserName, isLoading }) => { // Receive isLoading prop
  const [code, setCode] = useState("");
  const [name, setName] = useState("");

  useEffect(() => {
    if (savedFamilyCode) {
      setCode(savedFamilyCode);
    }
     if (savedUserName) {
      setName(savedUserName);
    }
  }, [savedFamilyCode, savedUserName]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (code.trim() && name.trim() && !isLoading) { // Prevent submit while loading
      onCodeSubmit(code.trim(), name.trim());
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="w-full max-w-sm mx-auto grocery-list-container">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold flex items-center justify-center">
             <Users className="h-6 w-6 mr-2 text-primary"/> Llista Familiar
          </CardTitle>
          <CardDescription>Entra amb el teu nom i codi familiar per accedir o crear una llista compartida.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="userName" className="flex items-center"><User className="h-4 w-4 mr-1"/>El Teu Nom</Label>
              <Input
                id="userName"
                type="text"
                placeholder="Ex: Joan"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="family-code-input"
                disabled={isLoading} // Disable input when loading
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="familyCode" className="flex items-center"><Users className="h-4 w-4 mr-1"/>Codi Familiar</Label>
              <Input
                id="familyCode"
                type="text"
                placeholder="Ex: familia_perez"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                required
                className="family-code-input"
                 disabled={isLoading} // Disable input when loading
              />
            </div>
             <Button type="submit" className="w-full" disabled={!code.trim() || !name.trim() || isLoading}>
                {isLoading ? (
                   <Loader2 className="h-4 w-4 mr-2 animate-spin" /> 
                ) : (
                   <LogIn className="h-4 w-4 mr-2"/> 
                )}
               {isLoading ? 'Entrant...' : 'Entrar'} 
             </Button>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default FamilyCodeForm;
