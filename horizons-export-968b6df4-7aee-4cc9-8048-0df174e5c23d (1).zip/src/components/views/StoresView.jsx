
import React from 'react';
import StoreManager from '@/components/StoreManager';
import { Loader2 } from 'lucide-react';

const StoresView = ({
  stores,
  onAddStore,
  onDeleteStore,
  onSelectStore,
  familyCode,
  userName,
  onLogout,
  onShowPurchased,
  isLoading
}) => {
  // Show loading specifically if stores are being loaded but haven't arrived yet
  if (isLoading && stores.length === 0) {
      return <div className="text-center p-10"><Loader2 className="h-6 w-6 animate-spin inline mr-2"/>Carregant botigues...</div>;
  }

  return (
    <StoreManager
      stores={stores}
      onAddStore={onAddStore}
      onDeleteStore={onDeleteStore}
      onSelectStore={onSelectStore}
      familyCode={familyCode}
      userName={userName}
      onLogout={onLogout}
      onShowPurchased={onShowPurchased}
      isLoading={isLoading} // Pass overall loading state for disabling inputs/buttons
    />
  );
};

export default StoresView;
