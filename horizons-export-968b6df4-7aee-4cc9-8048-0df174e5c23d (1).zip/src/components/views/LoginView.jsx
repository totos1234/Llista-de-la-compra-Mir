
    import React from 'react';
    import FamilyCodeForm from '@/components/FamilyCodeForm';

    // Receive isLoading which now represents isLoginActionLoading
    const LoginView = ({ onCodeSubmit, isLoading }) => {
      return (
        <FamilyCodeForm
          onCodeSubmit={onCodeSubmit}
          savedFamilyCode={localStorage.getItem("groceryAppFamilyCode") || ""}
          savedUserName={localStorage.getItem("groceryAppUserName") || ""}
          isLoading={isLoading} // Pass the loading state to the form
        />
      );
    };

    export default LoginView;
  