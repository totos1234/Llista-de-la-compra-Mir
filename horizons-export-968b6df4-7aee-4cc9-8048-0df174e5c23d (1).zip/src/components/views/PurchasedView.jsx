
import React from 'react';
import PurchasedItemsList from '@/components/PurchasedItemsList';
import { Loader2 } from 'lucide-react';

const PurchasedView = ({
  purchasedItems,
  pendingItemNames,
  onGoBack,
  onReAddItem,
  isLoading
}) => {
   if (isLoading) {
     return <div className="text-center p-10"><Loader2 className="h-6 w-6 animate-spin inline mr-2"/>Carregant historial...</div>;
   }

  return (
    <PurchasedItemsList
      purchasedItems={purchasedItems}
      pendingItemNames={pendingItemNames}
      onGoBack={onGoBack}
      onReAddItem={onReAddItem}
      isLoading={isLoading} // Pass loading state for UI disabling
    />
  );
};

export default PurchasedView;
