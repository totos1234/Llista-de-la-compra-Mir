
import React from 'react';
import GroceryListContainer from '@/components/GroceryListContainer';
import { Loader2 } from 'lucide-react'; // Assuming you might want a loading indicator here too

const ListView = ({
  store,
  familyId,
  userName,
  onLogout,
  onGoBack,
  onShowPurchased,
  onItemChange,
  isLoading // You might pass isLoading here if needed for the list view itself
}) => {
  // Optional: Add a loading state specific to this view if needed
  // if (isLoading) {
  //   return <div className="text-center p-10"><Loader2 className="h-6 w-6 animate-spin inline mr-2"/>Carregant llista...</div>;
  // }

  if (!store || !familyId) {
      // This case should ideally be handled by redirecting in App.jsx
      return <div className="text-center p-10">Error: Falta informació de la botiga o família.</div>;
  }

  return (
    <GroceryListContainer
      store={store}
      familyId={familyId}
      userName={userName}
      onLogout={onLogout}
      onGoBack={onGoBack}
      onShowPurchased={onShowPurchased}
      onItemChange={onItemChange}
      // Pass isLoading down if GroceryListContainer uses it
      // isLoading={isLoading}
    />
  );
};

export default ListView;
