
import { supabase } from '@/lib/supabaseClient';
import { handleSupabaseError } from '@/services/supabaseService';

export const loadStores = async (familyId) => {
  if (!familyId) return [];
  try {
    const { data, error } = await supabase
      .from('stores')
      .select('id, name')
      .eq('family_id', familyId)
      .order('created_at', { ascending: true });

    if (error) throw error;
    return data || [];
  } catch (error) {
    handleSupabaseError(error, 'loadStores');
    return [];
  }
};

export const addStore = async (familyId, storeName) => {
  if (!familyId || !storeName) {
      return { success: false, message: "Falta l'ID de família o el nom de la botiga." };
  }
  try {
    const { data, error } = await supabase
      .from('stores')
      .insert({ family_id: familyId, name: storeName.trim() })
      .select('id, name')
      .single();

    if (error) throw error;
    return { success: true, data: data };
  } catch (error) {
     return handleSupabaseError(error, 'addStore');
  }
};

export const deleteStore = async (storeId) => {
   if (!storeId) {
      return { success: false, message: "Falta l'ID de la botiga." };
   }
   try {
     const { error } = await supabase
       .from('stores')
       .delete()
       .eq('id', storeId);

     if (error) throw error;
     return { success: true };
   } catch (error) {
     return handleSupabaseError(error, 'deleteStore');
   }
};
