
    import React from "react";
    import { supabase } from '@/lib/supabaseClient';
    import { handleSupabaseError } from '@/services/supabaseService';

    export const getOrCreateFamily = async (familyCode) => {
      if (!familyCode || typeof familyCode !== 'string' || familyCode.trim() === '') {
        return { success: false, data: null, message: "El codi familiar no pot estar buit.", error: new Error("Family code is empty or invalid.") };
      }

      const trimmedCode = familyCode.trim();

      try {
        // 1. Check if family exists
        let { data: existingFamily, error: fetchError } = await supabase
          .from('families')
          .select('id, code')
          .eq('code', trimmedCode)
          .maybeSingle(); // Use maybeSingle to return null instead of error if not found

        // Handle unexpected errors during fetch
        if (fetchError) {
           // Allow 'PGRST116' (Row not found) to proceed to creation phase silently
           // Rethrow any other unexpected error
          if (fetchError.code !== 'PGRST116') {
            throw fetchError;
          }
          // If it *was* PGRST116, existingFamily will be null, handled below.
        }

        // 2. Return existing family if found
        if (existingFamily) {
          return { success: true, data: existingFamily, message: "Família trobada.", error: null };
        } else {
          // 3. Create new family if not found
          const { data: newFamily, error: insertError } = await supabase
            .from('families')
            .insert({ code: trimmedCode })
            .select('id, code')
            .single(); // Use single to expect exactly one row back after insert

          // Handle errors during insert (e.g., unique constraint violation if race condition)
          if (insertError) {
            throw insertError;
          }

          // 4. Return newly created family
          return { success: true, data: newFamily, message: "Família creada correctament.", error: null };
        }
      } catch (error) {
        // 5. Handle any caught errors (from fetch or insert)
        const handledError = handleSupabaseError(error, 'getOrCreateFamily');
         // Provide a fallback message if the handler didn't specify one
        const finalMessage = handledError.message || "S'ha produït un error en accedir o crear la família.";
        console.error("Error in getOrCreateFamily:", handledError.error); // Log the actual error for debugging
        return { success: false, data: null, message: finalMessage, error: handledError.error };
      }
    };
  